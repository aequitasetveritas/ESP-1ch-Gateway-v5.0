export const APP_NAME = process.env.REACT_APP_NAME;
