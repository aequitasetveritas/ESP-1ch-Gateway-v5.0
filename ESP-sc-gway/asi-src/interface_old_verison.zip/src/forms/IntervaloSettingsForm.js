import React from 'react';
import PropTypes from 'prop-types';

import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Switch from '@material-ui/core/Switch';
import LinearProgress from '@material-ui/core/LinearProgress';
import { TextValidator, ValidatorForm } from 'react-material-ui-form-validator';
import Typography from '@material-ui/core/Typography';
import FormControlLabel from '@material-ui/core/FormControlLabel';

import isIP from '../validators/isIP';
import isHostname from '../validators/isHostname';
import or from '../validators/or';
import PasswordValidator from '../components/PasswordValidator';

const styles = theme => ({
  loadingSettings: {
    margin: theme.spacing(0.5),
  },
  loadingSettingsDetails: {
    margin: theme.spacing(4),
    textAlign: "center"
  },
  switchControl: {
    width: "100%",
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(0.5)
  },
  textField: {
    width: "100%"
  },
  button: {
    marginRight: theme.spacing(2),
    marginTop: theme.spacing(2),
  }
});

class IntervaloSettingsForm extends React.Component {

  componentWillMount() {
  }

  render() {
    const { classes, otaSettingsFetched, otaSettings, errorMessage, handleValueChange, handleCheckboxChange, onSubmit, onReset } = this.props;
    return (
      <div>
        {
         !otaSettingsFetched ?

         <div className={classes.loadingSettings}>
           <LinearProgress className={classes.loadingSettingsDetails}/>
           <Typography variant="h4" className={classes.loadingSettingsDetails}>
             Loading...
           </Typography>
         </div>

         : otaSettings ?

      	 <ValidatorForm onSubmit={onSubmit}>

           <TextValidator
               validators={['required', 'isNumber', 'minNumber:0', 'maxNumber:65535']}
               errorMessages={['Intervalo es requerido', "Debe ser un numero", "Mayor a cero ", "Máximo is 65535"]}
               name="port"
               label="Intervalo (min)"
               className={classes.textField}
               value={otaSettings.intervalo}
               onChange={handleValueChange('intervalo')}
               type="number"
               margin="normal"
             />


          <Button variant="contained" color="primary" className={classes.button} type="submit">
               Guardar
          </Button>
          <Button variant="contained" color="secondary" className={classes.button} onClick={onReset}>
      		  Reset
      		</Button>

         </ValidatorForm>

        :

        <div className={classes.loadingSettings}>
          <Typography variant="h4" className={classes.loadingSettingsDetails}>
            {errorMessage}
          </Typography>
          <Button variant="contained" color="secondary" className={classes.button} onClick={onReset}>
      		  Reset
      		</Button>
        </div>
      }
      </div>
    );
  }
}

IntervaloSettingsForm.propTypes = {
  classes: PropTypes.object.isRequired,
  otaSettingsFetched: PropTypes.bool.isRequired,
  otaSettings: PropTypes.object,
  errorMessage: PropTypes.string,
  onSubmit: PropTypes.func.isRequired,
  onReset: PropTypes.func.isRequired,
  handleValueChange: PropTypes.func.isRequired,
  handleCheckboxChange: PropTypes.func.isRequired,
};

export default withStyles(styles)(IntervaloSettingsForm);
