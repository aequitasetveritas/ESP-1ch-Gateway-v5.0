import React, { Component } from 'react';
import { Redirect, Switch } from 'react-router-dom'

import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

import AuthenticatedRoute from '../authentication/AuthenticatedRoute';
import MenuAppBar from '../components/MenuAppBar';
import OTASettings from '../containers/OTASettings';
import SystemStatus from '../containers/SystemStatus';
import IntervaloSettings from '../containers/IntervaloSettings';
import { withAuthenticationContext } from '../authentication/Context.js';

class System extends Component {

  handleTabChange = (event, path) => {
    this.props.history.push(path);
  };

  render() {
    const { authenticationContext } = this.props;
    return (
      <MenuAppBar sectionTitle="Medición">
        <Tabs value={this.props.match.url} onChange={this.handleTabChange} indicatorColor="primary" textColor="primary" variant="fullWidth">
    
         <Tab value="/system/status" label="Medición" />
          <Tab value="/system/intervalo" label="Intervalo" disabled={!authenticationContext.isAdmin()} />
        </Tabs>
        <Switch>
          <AuthenticatedRoute exact={true} path="/system/status" component={SystemStatus} />
          <AuthenticatedRoute exact={true} path="/system/intervalo" component={IntervaloSettings} />
          <Redirect to="/system/status" />
        </Switch>
      </MenuAppBar>
    )
  }
}

     // <Tab value="/system/status" label="Syyystem Status" />
//<Tab value="/system/ota" label="OTA Settings" disabled={!authenticationContext.isAdmin()} />
//<AuthenticatedRoute exact={true} path="/system/ota" component={OTASettings} />
export default withAuthenticationContext(System);
