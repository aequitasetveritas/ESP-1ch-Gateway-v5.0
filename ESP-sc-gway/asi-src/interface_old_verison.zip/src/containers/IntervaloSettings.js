import React, { Component } from 'react';

import { INTERVALO_SETTINGS_ENDPOINT }  from  '../constants/Endpoints';
import {restComponent} from '../components/RestComponent';
import SectionContent from '../components/SectionContent';
import IntervaloSettingsForm from '../forms/IntervaloSettingsForm';

class IntervaloSettings extends Component {

  componentDidMount() {
      this.props.loadData();
  }

  render() {
    const { data, fetched, errorMessage } = this.props;
    return (
      <SectionContent title="Intervalo">
      	<IntervaloSettingsForm
          otaSettings={data}
          otaSettingsFetched={fetched}
          errorMessage={errorMessage}
          onSubmit={this.props.saveData}
          onReset={this.props.loadData}
          handleValueChange={this.props.handleValueChange}
          handleCheckboxChange={this.props.handleCheckboxChange}
        />
      </SectionContent>
    )
  }
}

export default restComponent(INTERVALO_SETTINGS_ENDPOINT, IntervaloSettings);
